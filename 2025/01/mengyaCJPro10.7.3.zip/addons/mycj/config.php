<?php

return array (
  0 => 
  array (
    'name' => 'api',
    'title' => '插件官网',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'https://www.dkewl.com/',
    'class' => 'id',
    'rule' => 'required',
    'msg' => '',
    'tip' => '无需配置，请直接点击启用后，在后台首页右侧的快捷菜单处进入管理',
    'ok' => '',
    'extend' => 'style="width:500px;height:38px;line-height: 34px;"',
  ),
);
