<?php
return array (
    'name' => '萌芽采集Pro插件',
    'copyright' => 'Mycj',
    'url' => 'https://www.mycj.pro/',
    'code' => 'v10.7.3',
);
?>